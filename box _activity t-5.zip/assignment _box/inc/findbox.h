#ifndef __FINDBOX_H
#define __FINDBOX_H

#include"box.h"


int find_box(int *bptr,int GivUniq_Id);


#endif