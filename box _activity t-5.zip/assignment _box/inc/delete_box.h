
#ifndef __DELETEBOX_H
#define __DELETEBOX_H

#include"box.h"


int delete_box(int *bptr,int GivUniq_Id);


#endif
