#ifndef __CALCVOLUME_H
#define __CALCVOLUME_H

#include"boxmodel.h"

unsigned long volume_of_box(Boxes *box1);
unsigned long avg_volume(Boxes *box1, unsigned int no_of_boxes);



#endif
