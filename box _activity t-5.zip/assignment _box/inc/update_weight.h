
#ifndef __UPDATEWEIGHT_H
#define __UPDATEWEIGHT_H

#include"box.h"

int update_weight(int *bptr,int GivUniq_Id, int GivenWeight);


#endif
